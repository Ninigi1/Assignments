#include <iostream>
using namespace std;

// Function declarations
unsigned int length(const char* str);
char* copy(char* dest, const char* src);
int indexOf(char c, const char* str);
char* substring(int i, int j, const char* str);
char* replace(char c, char p, const char* str);

int main() {
    // Test length function
    cout << "Testing length function:" << endl;
    cout << "length(\"string\") = " << length("string") << endl;
    cout << "length(\"hello world\") = " << length("hello world") << endl;

    // Test copy function
    cout << "\nTesting copy function:" << endl;
    char dest[20];
    cout << "copy(dest, \"string\") = " << copy(dest, "string") << endl;
    cout << "dest after copy = " << dest << endl;

    // Test indexOf function
    cout << "\nTesting indexOf function:" << endl;
    cout << "indexOf('i', \"string\") = " << indexOf('i', "string") << endl;
    cout << "indexOf('a', \"string\") = " << indexOf('a', "string") << endl;

    // Test substring function
    cout << "\nTesting substring function:" << endl;
    char* sub = substring(0, 3, "string");
    if (sub) {
        cout << "substring(0, 3, \"string\") = " << sub << endl;
        delete[] sub;
    } else {
        cout << "substring(0, 3, \"string\") = NULL" << endl;
    }

    // Test replace function
    cout << "\nTesting replace function:" << endl;
    char* rep = replace('i', 'x', "string");
    if (rep) {
        cout << "replace('i', 'x', \"string\") = " << rep << endl;
        delete[] rep;
    } else {
        cout << "replace('i', 'x', \"string\") = NULL" << endl;
    }

    return 0;
}
// Returns the length of the string excluding the null character `\0`.
unsigned int length(const char* str) {
    unsigned int len = 0;
    while (str[len] != '\0') {
        len++;
    }
    return len;
}

// Copies the string from `src` to `dest` including the null character.
char* copy(char* dest, const char* src) {
    if (dest == nullptr || src == nullptr) return nullptr;
    char* ptr = dest;
    while ((*ptr++ = *src++) != '\0');
    return dest;
}

// Returns the position of the first occurrence of character `c` in the string `str`.
int indexOf(char c, const char* str) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] == c) return i;
    }
    return -1;
}

// Returns a substring from index `i` to `j-1`.
char* substring(int i, int j, const char* str) {
    if (i < 0 || j <= i || str == nullptr) return nullptr;
    int len = j - i;
    char* sub = new char[len + 1];
    for (int k = 0; k < len; k++) {
        sub[k] = str[i + k];
    }
    sub[len] = '\0';
    return sub;
}

// Replaces every occurrence of character `c` with `p` in the string `str`.
char* replace(char c, char p, const char* str) {
    if (str == nullptr) return nullptr;
    int len = length(str);
    char* newStr = new char[len + 1];
    for (int i = 0; i < len; i++) {
        newStr[i] = (str[i] == c) ? p : str[i];
    }
    newStr[len] = '\0';
    return newStr;
}
