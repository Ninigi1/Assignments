#include <iostream>
#include "Matrix.h"

using namespace std;

/**
construct a matrix given the amount of rows m and columns n
set every value in the matrix to 0
@param m the amount of rows
@param n the amount of columns**/
Matrix::Matrix(unsigned int m, unsigned int n) {
    row = m;
    column = n;
    matrix = new int* [m];
    for (int i = 0; i < m; i++) {
        matrix[i] = new int[n];
        for (int j = 0; j < n; j++) {
            matrix[i][j] = 0;
        }
    }
}
/**
given an existing matrix, create a new matrix that copies every value
from the given matrix
@param mat an existing matrix to copy to a new matrix**/
Matrix::Matrix(const Matrix& mat) {
    row = mat.rows();
    column = mat.columns();
    matrix = new int* [row];
    for (int i = 0; i < row; i++) {
        matrix[i] = new int[column];
        for (int j = 0; j < column; j++) {
            matrix[i][j] = mat.get(i, j);
        }
    }
}
/**
given an existing array and the amount of rows and columns,
create a new matrix that copies every value
from the given array
@param m the amount of rows
@param n the amount of columns
@param array an existing array to copy the values to a new matrix**/
Matrix::Matrix(int** array, unsigned int m, unsigned int n) {
    row = m;
    column = n;
    matrix = new int* [row];
    for (int i = 0; i < row; i++) {
        matrix[i] = new int[column];
        for (int j = 0; j < column; j++) {
            matrix[i][j] = array[i][j];
        }
    }
}
/**
deconstructor that deletes the matrix and frees the memory
used by the matrix
**/
Matrix::~Matrix() {
    for (int i = 0; i < row; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

/**
getter method to get the amount of rows in the matrix
@return row the amount of rows in the matrix**/
unsigned int Matrix::rows() const {
    return row;
}
/**
getter method to get the amount of columns in the matrix
@return column the amount of columns in the matrix**/
unsigned int Matrix::columns() const {
    return column;
}

/**
getter method to get the value at a given coordinate in the matrix
@param i the row of the desired value
@param j the column of the desired value
@return matrix[i][j] the value at the given coordinate in the matrix**/
int Matrix::get(unsigned i, unsigned j) const {
    return matrix[i][j];
}
/**
setter method to set the value at a given coordinate in the matrix
@param i the row of the desired value
@param j the column of the desired value
@param value the new desired value
**/
void Matrix::set(unsigned i, unsigned j, int value) {
    matrix[i][j] = value;
}

/**
add two matrices together:
matrices are added together by adding each respective coordinate together
e.g matrix1[0][0] + matrix2[0][0] = matrix3[0][0]
both matrices must be the same size with the same dimensions in order
to be added together
@param mat the second matrix to be added to this matrix
@return result the matrix that is the result of adding two matrices together
**/
Matrix Matrix::operator+(const Matrix& mat) {
    if (row != mat.rows() || column != mat.columns()) {
        throw std::invalid_argument("Cannot add matrices as they are not the same size.");
    }

    Matrix result(row, column);

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
            result.set(i, j, matrix[i][j] + mat.get(i, j));
        }
    }

    return result;
}
/**
subtract two matrices from each other:
matrices are subtracted by subtracting each respective coordinate
e.g matrix1[0][0] - matrix2[0][0] = matrix3[0][0]
both matrices must be the same size with the same dimensions in order
to be subtracted
@param mat the second matrix to be subtracted from this matrix
@return result the matrix that is the result of subtracting two matrices
**/
Matrix Matrix::operator-(const Matrix& mat) {
    if (row != mat.rows() || column != mat.columns()) {
        throw std::invalid_argument("Cannot subtract matrices as they are not the same size.");
    }

    Matrix result(row, column);

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
            result.set(i, j, matrix[i][j] - mat.get(i, j));
        }
    }

    return result;
}
/**
multiply two matrices together:
the amount of rows in matrix A must be equal to the amount of columns in matrix B
@param mat the second matrix to be added to this matrix
@return result the matrix that is the result of adding two matrices together
**/
Matrix Matrix::operator*(const Matrix& mat) {
    if (column != mat.rows()) {
        throw std::invalid_argument("Cannot multiply matrices as they are the incorrect size.");
    }

    Matrix result(row, mat.columns());

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < mat.columns(); j++) {
            for (int k = 0; k < column; k++) {
                result.set(i, j, result.get(i, j) + (matrix[i][k] * mat.get(k, j)));
            }
        }
    }

    return result;
}

/**
get the transpose of the matrix:
the transpose of the matrix is gotten by essentially swapping the x and y cooridnates
for each value and swapping the dimensions of the matrix
@return result the matrix that is the result of transposing the initial matrix
**/
Matrix Matrix::operator~() const {
    Matrix result(column, row);

    for (int i = 0; i < column; i++) {
        for (int j = 0; j < row; j++) {
            result.set(i, j, matrix[j][i]);
        }
    }

    return result;
}
/* *
* check if two matrices are the same : two matrices are the same
* if they both contain the same element at the same location in
* each matrix .
* @param mat is another matrix
* @return true if both are the same , otherwise false .
*/
bool Matrix::operator==(const Matrix& mat) {
    if (row != mat.rows() || column != mat.columns()) {
        throw std::invalid_argument("Cannot compare matrices as they are not the same size.");
    }

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
            if (matrix[i][j] != mat.get(i, j)) {
                return false;
            }
        }
    }

    return true;

}
/*
convert the matrix into a string format
@return output the matrix in string format
*/
std::string Matrix::toStr() {
    string output = "";
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
            output += std::to_string(matrix[i][j]) + " ";
        }
        output += "\n";
    }
    return output;
}