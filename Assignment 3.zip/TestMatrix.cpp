#include <iostream>
#include <vector>
#include <string>

#include "Matrix.h"

using namespace std;

class Tests {
public:

    static void run_Tests() {
        Test_Case_1_Plus();
        Test_Case_1_Minus();
        Test_Case_1_Multiply();
        Test_Case_1_Transpose();
        Test_Case_1_Compare();
    }

    static void Test_Case_1_Plus() {
        int** arr1 = new int* [2];
        int** arr2 = new int* [2];
        arr1[0] = new int[2];
        arr1[1] = new int[2];
        arr2[0] = new int[2];
        arr2[1] = new int[2];

        arr1[0][0] = 2;
        arr1[0][1] = 3;
        arr1[1][0] = 4;
        arr1[1][1] = 5;
        arr2[0][0] = 2;
        arr2[0][1] = 3;
        arr2[1][0] = 4;
        arr2[1][1] = 5;
        Matrix m1 = Matrix(arr1, 2, 2);
        Matrix m2 = Matrix(arr2, 2, 2);

        Matrix m3 = m1 + m2;
        string output = "4 6 \n8 10 \n";
        if (output == m3.toStr()) {
            cout << "Plus test passed" << endl;
        }
        else {
            cout << "Plus test failed" << endl;
            cout << "ExpectedOutput: " << output << endl;
            cout << "ActualOutput: " << m3.toStr() << endl;
        }
    }

    static void Test_Case_1_Minus() {
        int** arr1 = new int* [2];
        int** arr2 = new int* [2];
        arr1[0] = new int[2];
        arr1[1] = new int[2];
        arr2[0] = new int[2];
        arr2[1] = new int[2];

        arr1[0][0] = 2;
        arr1[0][1] = 3;
        arr1[1][0] = 4;
        arr1[1][1] = 5;
        arr2[0][0] = 1;
        arr2[0][1] = 2;
        arr2[1][0] = 3;
        arr2[1][1] = 4;
        Matrix m1 = Matrix(arr1, 2, 2);
        Matrix m2 = Matrix(arr2, 2, 2);

        Matrix m3 = m1 - m2;
        string output = "1 1 \n1 1 \n";
        if (output == m3.toStr()) {
            cout << "Minus test passed" << endl;
        }
        else {
            cout << "Minus test failed" << endl;
            cout << "ExpectedOutput: " << output << endl;
            cout << "ActualOutput: " << m3.toStr() << endl;
        }
    }

    static void Test_Case_1_Multiply() {
        int** arr1 = new int* [2];
        int** arr2 = new int* [2];
        arr1[0] = new int[2];
        arr1[1] = new int[2];
        arr2[0] = new int[1];
        arr2[1] = new int[1];

        arr1[0][0] = 2;
        arr1[0][1] = 3;
        arr1[1][0] = 4;
        arr1[1][1] = 5;
        arr2[0][0] = 2;
        arr2[1][0] = 3;
        Matrix m1 = Matrix(arr1, 2, 2);
        Matrix m2 = Matrix(arr2, 2, 1);

        Matrix m3 = m1 * m2;
        string output = "13 \n23 \n";
        if (output == m3.toStr()) {
            cout << "Multiply test passed" << endl;
        }
        else {
            cout << "Multiply test failed" << endl;
            cout << "ExpectedOutput: " << output << endl;
            cout << "ActualOutput: " << m3.toStr() << endl;
        }
    }

    static void Test_Case_1_Transpose() {
        int** arr1 = new int* [2];
        int** arr2 = new int* [2];
        arr1[0] = new int[2];
        arr1[1] = new int[2];
        arr2[0] = new int[1];
        arr2[1] = new int[1];

        arr1[0][0] = 2;
        arr1[0][1] = 3;
        arr1[1][0] = 4;
        arr1[1][1] = 5;
        arr2[0][0] = 2;
        arr2[1][0] = 3;
        Matrix m1 = Matrix(arr1, 2, 2);
        Matrix m2 = Matrix(arr2, 2, 1);

        Matrix m3 = ~m1;
        string output = "2 3 \n4 5 \n";
        if (output == m1.toStr()) {
            cout << "Transpose test passed" << endl;
        }
        else {
            cout << "Transpose test failed" << endl;
            cout << "ExpectedOutput: " << output << endl;
            cout << "ActualOutput: " << m3.toStr() << endl;
        }
    }

    static void Test_Case_1_Compare() {
        int** arr1 = new int* [2];
        arr1[0] = new int[2];
        arr1[1] = new int[2];

        arr1[0][0] = 2;
        arr1[0][1] = 3;
        arr1[1][0] = 4;
        arr1[1][1] = 5;
        Matrix m1 = Matrix(arr1, 2, 2);
        Matrix m2 = Matrix( 2, 2);

        Matrix m3 = Matrix(m1);
        string output = "2 3 \n4 5 \n";
        if (m1 == m3 && (m1 == m2) == 0) {
            cout << "Compare test passed" << endl;
        }
        else {
            cout << "Compare test failed" << endl;
            cout << "ExpectedOutput: " << output << endl;
            cout << "ActualOutput: " << m1.toStr() << endl;
        }
    }
};

int main()
{
    Tests::run_Tests();
}