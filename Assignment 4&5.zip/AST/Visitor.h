#ifndef VISITOR_H
#define VISITOR_H

#include <string>

using namespace std;

class Expr;
class AddExpr;
class SubExpr;
class MulExpr;
class DivExpr;
class ModExpr;
class ConstExpr;

class Visitor {
    /*
    * base visitor class, creates pure virtual methods for each Expr subclass
    */
public:
    virtual double visit (Expr* expression) = 0;
    virtual double visit (AddExpr* expression) = 0;
    virtual double visit (SubExpr* expression) = 0;
    virtual double visit (MulExpr* expression) = 0;
    virtual double visit (DivExpr* expression) = 0;
    virtual double visit (ModExpr* expression) = 0;
    virtual double visit (ConstExpr* expression) = 0;
    virtual ~Visitor() = default;

};

#endif