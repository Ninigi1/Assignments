#ifndef EXPR_H
#define EXPR_H

#include <string>

#include "Visitor.h"

using namespace std;

class Expr {
    /*
    * base Expr class, creates pure virtual methods for subclasses
    */
public:
    virtual string toStr() = 0;
    virtual double eval(Visitor* visitor) = 0;
    virtual ~Expr() = default;
};

class ConstExpr: public Expr {
public:
    int num;
    /*
    * ConstExpr constructor, takes in integer and stores it in num.
    */
    ConstExpr(int value) {
        num = value;
    }
    /*
    * converts local num to string and returns it
    * @return a string of the local number stores in ConstExpr
    */
    string toStr() override {
        return to_string(num);
    }
    /*
    * returns the local variable as an int to evaluate if 
    * ConstExpr stores values correctly.
    * @return the local int stored .
    */
    double eval(Visitor* visitor) override {
        return num;
    }
};

class BinaryExpr : public Expr {
public:
    Expr* LeftExpr;
    Expr* RightExpr;

    BinaryExpr(Expr* left, Expr* right) : LeftExpr(left), RightExpr(right) {}

    string toStr() override {
        return "Overidden";
    }
    /*
    * returns the visitor visit result to evaluate if 
    * BinaryExpr stores values correctly..
    * @return the result of visitor visiting this class.
    */
    double eval(Visitor* visitor) override {
        return visitor->visit(this);
    }
    /*
    * retrieve the left expression of a binary expression .
    * @return a pointer that points to the left
    * expression of a binary expression .
    */
    Expr* getLeftExpr() {
        return LeftExpr;
    }
    /*
    * set the left expression of a binary expression .
    * @take a expression as a parameter and assign it
    * to the left expression of a binary expression .
    */
    void setLeftExpr(Expr* left) {
        LeftExpr = left;
    }
    /*
    * retrieve the right expression of a binary expression .
    * @return a pointer that points to the right
    * expression of a binary expression .
    */
    Expr* getRightExpr() {
        return RightExpr;
    }
    /*
    * set the right expression of a binary expression .
    * @take a expression as a parameter and assign it
    * to the right expression of a binary expression .
    */
    void setRightExpr(Expr* right) {
        RightExpr = right;
    }
};

class AddExpr : public BinaryExpr {
public:
    using BinaryExpr::BinaryExpr;
    /*
    * converts local expressions to addition string and returns it
    * @return a string of the local expressions in an addition expression
    */
    string toStr() override {
        return LeftExpr->toStr() + "+" + RightExpr->toStr();
    }
    /*
    * returns the visitor visit result to evaluate if 
    * AddExpr expression is valid and can be operated
    * @return the result of visitor visiting this class.
    */
    double eval(Visitor* visitor) override {
        return visitor->visit(this);
    }
};

class SubExpr : public BinaryExpr {
public:
    using BinaryExpr::BinaryExpr;
    /*
    * converts local expressions to subtraction string and returns it
    * @return a string of the local expressions in an subtraction expression
    */
    string toStr() override {
        return LeftExpr->toStr() + "-" + RightExpr->toStr();
    }
    /*
    * returns the visitor visit result to evaluate if 
    * SubExpr expression is valid and can be operated
    * @return the result of visitor visiting this class.
    */
    double eval(Visitor* visitor) override {
        return visitor->visit(this);
    }
};

class MulExpr : public BinaryExpr {
public:
    using BinaryExpr::BinaryExpr;
    /*
    * converts local expressions to multiplication string and returns it
    * @return a string of the local numbers in an multiplication expression
    */
    string toStr() override {
        return LeftExpr->toStr() + "*" + RightExpr->toStr();
    }
    /*
    * returns the visitor visit result to evaluate if 
    * MulExpr expression is valid and can be operated
    * @return the result of visitor visiting this class.
    */
    double eval(Visitor* visitor) override {
        return visitor->visit(this);
    }
};

class DivExpr : public BinaryExpr {
public:
    using BinaryExpr::BinaryExpr;
    /*
    * converts local expressions to division string and returns it
    * @return a string of the local numbers in an division expression
    */
    string toStr() override {
        return LeftExpr->toStr() + "/" + RightExpr->toStr();
    }
    /*
    * returns the visitor visit result to evaluate if 
    * DivExpr expression is valid and can be operated
    * @return the result of visitor visiting this class.
    */
    double eval(Visitor* visitor) override {
        return visitor->visit(this);
    }
};

class ModExpr : public BinaryExpr {
public:
    using BinaryExpr::BinaryExpr;
    /*
    * converts local expressions to modulus string and returns it
    * @return a string of the local numbers in an modulus expression
    */
    string toStr() override {
        return LeftExpr->toStr() + "%" + RightExpr->toStr();
    }
    /*
    * returns the visitor visit result to evaluate if 
    * ModExpr expression is valid and can be operated
    * @return the result of visitor visiting this class.
    */
    double eval(Visitor* visitor) override {
        return visitor->visit(this);
    }
};

#endif