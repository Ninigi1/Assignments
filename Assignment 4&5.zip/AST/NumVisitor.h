#ifndef NUMVISITOR_H
#define NUMVISITOR_H

#include "Visitor.h"
#include "Expr.h"

class NumVisitor : public Visitor {
    /*
    * returns the value of 0 since the base class doesn't store values
    * @return 0 as 
    */
    double visit (Expr* expression) override {
         return 0;
    }
    /*
    * takes both expressions in an add expression and adds them together to evaluate the expression
    * @return the addition of the left and right expression in an AddExpr
    */
    double visit (AddExpr* expression) override {
        Expr* LeftExpr = expression->getLeftExpr();
        Expr* RightExpr = expression->getRightExpr();
        int LeftValue = LeftExpr->eval(this);
        int RightValue = RightExpr->eval(this);
        return LeftValue + RightValue; 
    }
    /*
    * takes both expressions in an sub expression and subtracts them together to evaluate the expression
    * @return the subtraction of the left and right expression in a SubExpr
    */
    double visit (SubExpr* expression) override {
        Expr* LeftExpr = expression->getLeftExpr();
        Expr* RightExpr = expression->getRightExpr();
        int LeftValue = LeftExpr->eval(this);
        int RightValue = RightExpr->eval(this);
        return LeftValue - RightValue; 
    }
    /*
    * takes both expressions in an mul expression and multiplies them together to evaluate the expression
    * @return the multiplication of the left and right expression in a MulExpr
    */
    double visit (MulExpr* expression) override {
        Expr* LeftExpr = expression->getLeftExpr();
        Expr* RightExpr = expression->getRightExpr();
        int LeftValue = LeftExpr->eval(this);
        int RightValue = RightExpr->eval(this);
        return LeftValue * RightValue; 
    }
    /*
    * takes both expressions in an add expression and divides them together to evaluate the expression
    * @return the division of the left and right expression in a DivExpr
    */
    double visit (DivExpr* expression) override {
        Expr* LeftExpr = expression->getLeftExpr();
        Expr* RightExpr = expression->getRightExpr();
        int LeftValue = LeftExpr->eval(this);
        int RightValue = RightExpr->eval(this);
        return LeftValue / RightValue; 
    }
    /*
    * takes both expressions in an mod expression and mods them together to evaluate the expression
    * @return the modulus of the left and right expression in a ModExpr
    */
    double visit (ModExpr* expression) override {
        Expr* LeftExpr = expression->getLeftExpr();
        Expr* RightExpr = expression->getRightExpr();
        int LeftValue = LeftExpr->eval(this);
        int RightValue = RightExpr->eval(this);
        return LeftValue % RightValue; 
    }
    /*
    * takes the expression and returns the value stores to evaluate the expression
    * @return the value stores in the ConstExpr
    */
    double visit (ConstExpr* expression) override {
        return expression->eval(this);
    }
};

#endif