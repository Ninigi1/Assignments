#include <iostream>
#include <string>

#include "Tests.h"

int main()
{
    Tests::run_Tests();
}