#ifndef TESTS_H
#define TESTS_H

#include <iostream>

#include "Expr.h"
#include "NumVisitor.h"

using namespace std;

class Tests {
    /*
    * class for running tests for Expr subclasses
    */
public: 
    /*
    * runs all local tests to check if each Expr class is working as intended
    */
    static void run_Tests(){
        Test_Case_AddExpr();
        Test_Case_SubExpr();
        Test_Case_MulExpr();
        Test_Case_DivExpr();
        Test_Case_ModExpr();
    }

    /*
    * creates an AddExpr and checks if both output from toStr() and eval() are returning intended results
    * prints out any errors it encounters or success message if there are no issues
    */
    static void Test_Case_AddExpr() {
        ConstExpr * c1 = new ConstExpr(3);
        ConstExpr * c2 = new ConstExpr(4);
        AddExpr * e1 = new AddExpr ( c1 , c2 );
        Visitor * visitor = new NumVisitor ();

        string ExpectedOutput = "3+4";
        int ExpectedEval = 3+4;
        string ActualOutput = e1->toStr();
        int ActualEval = e1->eval(visitor);

        bool Output = ExpectedOutput == ActualOutput;
        bool Eval = ExpectedEval == ActualEval;

        if (Output == false || Eval == false) {
            cout<<"AddExpr tests failed"<<endl;
            if(Output == false) {
                cout<<"Output did not match"<<endl;
                cout<<"Expected Output: "<<ExpectedOutput<<endl;
                cout<<"Actual Output: "<<ActualOutput<<endl;
            }
            if (Eval == false) {
                cout<<"Eval did not match"<<endl;
                cout<<"Expected Eval: "<<ExpectedEval<<endl;
                cout<<"Actual Eval: "<<ActualEval<<endl;
            }
        }
        else {
            cout<<"AddExpr tests passed"<<endl;
        }
    }

    /*
    * creates an SubExpr and checks if both output from toStr() and eval() are returning intended results
    * prints out any errors it encounters or success message if there are no issues
    */
    static void Test_Case_SubExpr() {
        ConstExpr * c1 = new ConstExpr(7);
        ConstExpr * c2 = new ConstExpr(4);
        SubExpr * e1 = new SubExpr ( c1 , c2 );
        Visitor * visitor = new NumVisitor ();

        string ExpectedOutput = "7-4";
        int ExpectedEval = 7-4;
        string ActualOutput = e1->toStr();
        int ActualEval = e1->eval(visitor);

        bool Output = ExpectedOutput == ActualOutput;
        bool Eval = ExpectedEval == ActualEval;

        if (Output == false || Eval == false) {
            cout<<"SubExpr tests failed"<<endl;
            if(Output == false) {
                cout<<"Output did not match"<<endl;
                cout<<"Expected Output: "<<ExpectedOutput<<endl;
                cout<<"Actual Output: "<<ActualOutput<<endl;
            }
            if (Eval == false) {
                cout<<"Eval did not match"<<endl;
                cout<<"Expected Eval: "<<ExpectedEval<<endl;
                cout<<"Actual Eval: "<<ActualEval<<endl;
            }
        }
        else {
            cout<<"SubExpr tests passed"<<endl;
        }
    }  

    /*
    * creates an MulExpr and checks if both output from toStr() and eval() are returning intended results
    * prints out any errors it encounters or success message if there are no issues
    */

    static void Test_Case_MulExpr() {
        ConstExpr * c1 = new ConstExpr(9);
        ConstExpr * c2 = new ConstExpr(3);
        MulExpr * e1 = new MulExpr ( c1 , c2 );
        Visitor * visitor = new NumVisitor ();

        string ExpectedOutput = "9*3";
        int ExpectedEval = 9*3;
        string ActualOutput = e1->toStr();
        int ActualEval = e1->eval(visitor);

        bool Output = ExpectedOutput == ActualOutput;
        bool Eval = ExpectedEval == ActualEval;

        if (Output == false || Eval == false) {
            cout<<"MulExpr tests failed"<<endl;
            if(Output == false) {
                cout<<"Output did not match"<<endl;
                cout<<"Expected Output: "<<ExpectedOutput<<endl;
                cout<<"Actual Output: "<<ActualOutput<<endl;
            }
            if (Eval == false) {
                cout<<"Eval did not match"<<endl;
                cout<<"Expected Eval: "<<ExpectedEval<<endl;
                cout<<"Actual Eval: "<<ActualEval<<endl;
            }
        }
        else {
            cout<<"MulExpr tests passed"<<endl;
        }
    }   

    /*
    * creates an DivExpr and checks if both output from toStr() and eval() are returning intended results
    * prints out any errors it encounters or success message if there are no issues
    */

    static void Test_Case_DivExpr() {
        ConstExpr * c1 = new ConstExpr(8);
        ConstExpr * c2 = new ConstExpr(2);
        DivExpr * e1 = new DivExpr ( c1 , c2 );
        Visitor * visitor = new NumVisitor ();

        string ExpectedOutput = "8/2";
        int ExpectedEval = 8/2;
        string ActualOutput = e1->toStr();
        int ActualEval = e1->eval(visitor);

        bool Output = ExpectedOutput == ActualOutput;
        bool Eval = ExpectedEval == ActualEval;

        if (Output == false || Eval == false) {
            cout<<"DivExpr tests failed"<<endl;
            if(Output == false) {
                cout<<"Output did not match"<<endl;
                cout<<"Expected Output: "<<ExpectedOutput<<endl;
                cout<<"Actual Output: "<<ActualOutput<<endl;
            }
            if (Eval == false) {
                cout<<"Eval did not match"<<endl;
                cout<<"Expected Eval: "<<ExpectedEval<<endl;
                cout<<"Actual Eval: "<<ActualEval<<endl;
            }
        }
        else {
            cout<<"DivExpr tests passed"<<endl;
        }
    }   

    /*
    * creates an ModExpr and checks if both output from toStr() and eval() are returning intended results
    * prints out any errors it encounters or success message if there are no issues
    */

    static void Test_Case_ModExpr() {
        ConstExpr * c1 = new ConstExpr(7);
        ConstExpr * c2 = new ConstExpr(2);
        ModExpr * e1 = new ModExpr ( c1 , c2 );
        Visitor * visitor = new NumVisitor ();

        string ExpectedOutput = "7%2";
        int ExpectedEval = 7%2;
        string ActualOutput = e1->toStr();
        int ActualEval = e1->eval(visitor);

        bool Output = ExpectedOutput == ActualOutput;
        bool Eval = ExpectedEval == ActualEval;

        if (Output == false || Eval == false) {
            cout<<"ModExpr tests failed"<<endl;
            if(Output == false) {
                cout<<"Output did not match"<<endl;
                cout<<"Expected Output: "<<ExpectedOutput<<endl;
                cout<<"Actual Output: "<<ActualOutput<<endl;
            }
            if (Eval == false) {
                cout<<"Eval did not match"<<endl;
                cout<<"Expected Eval: "<<ExpectedEval<<endl;
                cout<<"Actual Eval: "<<ActualEval<<endl;
            }
        }
        else {
            cout<<"ModExpr tests passed"<<endl;
        }
    }   
};

#endif