#include <iostream>

// Function definitions
int reverseInteger(int num) {
    int reversedNumber = 0;
    while (num != 0) {
        int remainder = num % 10;
        reversedNumber = reversedNumber * 10 + remainder;
        num /= 10;
    }
    return reversedNumber;
}

int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

bool isPalindrome(int num) {
    if (num < 0) return false;
    int originalNum = num, reversedNum = 0;
    while (num != 0) {
        int remainder = num % 10;
        reversedNum = reversedNum * 10 + remainder;
        num /= 10;
    }
    return originalNum == reversedNum;
}

double power(double x, int y) {
    if (y == 0) return 1;
    double half = power(x, y / 2);
    if (y % 2 == 0)
        return half * half;
    else
        return half * half * x;
}

bool isPowerOfTwo(int num) {
    if (num <= 0) return false;
    return (num & (num - 1)) == 0;
}

int main() {
    int choice;
    std::cout << "Choose a problem to solve:\n";
    std::cout << "1. Reverse an Integer\n";
    std::cout << "2. Greatest Common Divisor\n";
    std::cout << "3. Palindrome Number\n";
    std::cout << "4. Power Function\n";
    std::cout << "5. Power of Two\n";
    std::cout << "Enter your choice: ";
    std::cin >> choice;

    switch (choice) {
        case 1: {
            int number;
            std::cout << "Enter an integer: ";
            std::cin >> number;
            std::cout << "Reversed integer: " << reverseInteger(number) << std::endl;
            break;
        }
        case 2: {
            int num1, num2;
            std::cout << "Enter two integers: ";
            std::cin >> num1 >> num2;
            std::cout << "Greatest Common Divisor: " << gcd(num1, num2) << std::endl;
            break;
        }
        case 3: {
            int number;
            std::cout << "Enter an integer: ";
            std::cin >> number;
            std::cout << "Is palindrome: " << (isPalindrome(number) ? "true" : "false") << std::endl;
            break;
        }
        case 4: {
            double base;
            int exponent;
            std::cout << "Enter base and exponent: ";
            std::cin >> base >> exponent;
            std::cout << "Result: " << power(base, exponent) << std::endl;
            break;
        }
        case 5: {
            int number;
            std::cout << "Enter an integer: ";
            std::cin >> number;
            std::cout << "Is power of two: " << (isPowerOfTwo(number) ? "true" : "false") << std::endl;
            break;
        }
        default:
            std::cout << "Invalid choice. Please select a number between 1 and 5." << std::endl;
            break;
    }

    return 0;
}

